﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            double NegSumma = 0;
            int coutner = 0;
            while (true)
            {
                double x = Convert.ToDouble(Console.ReadLine());
                if (x == 0) break;

                if (x<0)
                {
                    NegSumma += x;
                    coutner++;
                }
            }
            Console.WriteLine("среднее арифмитическое отрицательных чисел равно {0}", NegSumma / coutner);
            Console.ReadLine();
        }


    }
}
